/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/util/MockServer"
], function(MockServer) {
	"use strict";
	return {
		/**
		 * Initializes the mock server.
		 * You can configure the delay with the URL parameter "serverDelay".
		 * The local mock data in this folder is returned instead of the real data for testing.
		 * @public
		 */
		init: function() {
			// create
			var rootUrl = /.*\/$/.test("/sap/opu/odata/sap/CV_ATTACHMENT_SRV/") ? "/sap/opu/odata/sap/CV_ATTACHMENT_SRV/" :
				"/sap/opu/odata/sap/CV_ATTACHMENT_SRV/" + "/";
			
			var oMockServer = new MockServer({
				rootUri: rootUrl
			});
			//configure
			MockServer.config({
				autoRespond: true,
				autoRespondAfter: 1000
			});
			//simulate
			oMockServer.simulate("/resources/sap/se/mi/plm/lib/attachmentservice/attachment/localService/metadata.xml", {
				sMockdataBaseUrl: "/resources/sap/se/mi/plm/lib/attachmentservice/attachment/localService/mockdata",
				bGenerateMissingMockData: true
			});

			var aRequests = oMockServer.getRequests();
			var sURLParamsPayload = {
				"d": {
					"__metadata": {
						"type": "Collection(CV_ATTACHMENT_SRV.OriginalUploadParams)"
					},
					"results": [{
						"__metadata": {
							"type": "CV_ATTACHMENT_SRV.OriginalUploadParams"
						},
						"ApplicationId": "8CDCD4000C701EE7B190C70024DE0463",
						"FileId": "8CDCD4000C701EE7B190C70024DE4463",
						"OriginalUrl": "",
						"Storagecategory": "HCP-DS.001",
						"ContentType": "text/plain",
						"URLToReadAttachment": "",
						"URLToUploadAttachment": "https%3a%2f%2localhost:8080%3a443%2farchivelink%2fcommand%3fcreate%26pVersion%3d0047%26contRep%3dHCP-DS.001%26docId%3d8CDCD4000C701EE7B190C70024DE4463%26docProt%3ddru%26accessMode%3dc%26authId%3dCN%253DER9%2cOU%253DDLM%26expiration%3d20171108151040%26secKey%3dMIIBCAYJKoZIhvcNAQcCoIH6MIH3AgEBMQswCQYFKw4DAhoFADALBgkqhkiG9w0BBwExgdcwgdQCAQEwKDAcMQwwCgYDVQQLEwNETE0xDDAKBgNVBAMTA0VSOQIICiAVBxISJgEwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE3MTEwODEzMTA0MFowIwYJKoZIhvcNAQkEMRYEFJ3wp9Tgl7IdHdmkG9BFpznipX18MAkGByqGSM44BAMEMDAuAhUAurjeFvw5y%252Be%252FCRLiXGVMWyRgG4ECFQCueO30aqi5JxjN4eSdHMZwXNY13A%253D%253D",
						"URLToUpdateAttachment": "",
						"SecureAccessToken": "FD3FQFFCWBJLLPZ9MSFKLYK1XCR4WPOZBTD0HYGX",
						"SecureAccessCookie": ""
					}, {
						"__metadata": {
							"type": "CV_ATTACHMENT_SRV.OriginalUploadParams"
						},
						"ApplicationId": "8CDCD4000C701EE7B190C70024DE0463",
						"FileId": "8CDCD4000C701EE7B190C70024DE4463",
						"OriginalUrl": "",
						"Storagecategory": "HCP-DS.001",
						"ContentType": "text/plain",
						"URLToReadAttachment": "",
						"URLToUploadAttachment": "https%3a%2f%2localhost:8080%3a443%2farchivelink%2fcommand%3fcreate%26pVersion%3d0047%26contRep%3dHCP-DS.001%26docId%3d8CDCD4000C701EE7B190C70024DE4463%26docProt%3ddru%26accessMode%3dc%26authId%3dCN%253DER9%2cOU%253DDLM%26expiration%3d20171108151040%26secKey%3dMIIBCAYJKoZIhvcNAQcCoIH6MIH3AgEBMQswCQYFKw4DAhoFADALBgkqhkiG9w0BBwExgdcwgdQCAQEwKDAcMQwwCgYDVQQLEwNETE0xDDAKBgNVBAMTA0VSOQIICiAVBxISJgEwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE3MTEwODEzMTA0MFowIwYJKoZIhvcNAQkEMRYEFJ3wp9Tgl7IdHdmkG9BFpznipX18MAkGByqGSM44BAMEMDAuAhUAurjeFvw5y%252Be%252FCRLiXGVMWyRgG4ECFQCueO30aqi5JxjN4eSdHMZwXNY13A%253D%253D",
						"URLToUpdateAttachment": "",
						"SecureAccessToken": "DFNG9Y2DPBALR5JY8UXLCOLHPNRPBLN0JHWO3T21",
						"SecureAccessCookie": ""
					}]
				}
			};
			aRequests.push({
				method: "GET",
				path: new RegExp("(.*)GetUploadURLWithToken(.*)"),
				response: function(oXhr, sUrlParams) {
					oXhr.respondJSON(200, {}, sURLParamsPayload);
					return true;
				}
			});
			// aRequests.push({
			// 	method: "POST",
			// 	path: new RegExp("GetAccessURLWithToken(.*)"),
			// 	response: function(oXhr, sUrlParams) {
			// 		oXhr.respondJSON(200, {}, JSON.stringify(sURLParamsPayload));
			// 		return true;
			// 	}
			// });
			// aRequests.push({
			// 	method: "POST",
			// 	path: new RegExp("CheckOut(.*)"),
			// 	response: function(oXhr, sUrlParams) {
			// 		var response = {
			// 			"Documenttype": "111",
			// 			"Documentnumber": "",
			// 			"Documentpart": "",
			// 			"Documentversion": "",
			// 			"ApplicationId": "8CDCD4008ED01EE78DAD9A8B729A6D44",
			// 			"FileId": "8CDCD4008ED01EE78DAD9A8B729AAD44",
			// 			"Wsapplication": "TXT",
			// 			"MarkForDeletion": false,
			// 			"Filesize": "000000000004",
			// 			"Filename": "njnj (1).txt",
			// 			"ContentSource": "",
			// 			"ContentType": "text/plain",
			// 			"Content": "",
			// 			"CreatedBy": "GUPTAPAN",
			// 			"FullName": "Pankaj Gupta"
			// 		};
			// 		oXhr.respondJSON(200, {}, JSON.stringify(response));
			// 		return true;
			// 	}
			// });
			oMockServer.setRequests(aRequests);
			// start
			oMockServer.start();
			jQuery.sap.log.info("Running the app with mock data");
		}
	};
});
