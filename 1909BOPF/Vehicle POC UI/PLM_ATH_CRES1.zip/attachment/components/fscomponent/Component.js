/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/se/mi/plm/lib/attachmentservice/attachment/Component"],function(A){"use strict";var C=A.extend("sap.se.mi.plm.lib.attachmentservice.attachment.components.fscomponent.Component",{metadata:{manifest:"json",library:"sap.se.mi.plm.lib.attachmentservice",publicMethods:["save","cancel","refresh","getApplicationState","getAttachmentCount"]}});return C;});
