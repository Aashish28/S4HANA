/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox"
], function (UI5Object, MessageBox) {
	"use strict";
	return {
		loadValueHelpDialog: function (isAssign) {
			//----handle respective F4 help layout details
			var that = this;
			that.aTokens = [];
			that.isAssign = isAssign;
			that.aKeys = ["DocumentInfoRecord", "DocumentInfoRecordDocNumber", "DocumentInfoRecordDocType", "DocumentInfoRecordDocVersion",
				"DocumentInfoRecordDocPart",
				"DocumentDescription", "FileName"
			];
			var staticKeys = ["DocumentInfoRecord", "DocumentInfoRecordDocNumber", "DocumentInfoRecordDocType", "DocumentInfoRecordDocVersion",
				"DocumentInfoRecordDocPart", "DocumentDescription", "FileName"
			];
			var i18nKeyData = ["ObjectKey", "Number", "Type", "Version", "Part", "Desc", "FileName"];
			//if (!that.oValueHelpDialog) {
			that.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: that.getView().getModel("i18n").getResourceBundle().getText("AssignDIR"),
				supportMultiselect: true,
				key: that.aKeys[0],
				stretch: sap.ui.Device.system.phone,
				supportRanges: false,
				supportRangesOnly: false,
				ok: function (oControlEvent) {
					that.aTokens = oControlEvent.getParameter("tokens");
					var selectedRows = that.oValueHelpDialog.getTable().getSelectedIndices();
					if (that.aTokens.length > 0) {
						for (var i = 0; i < that.aTokens.length; i++) {
							jQuery.each(selectedRows, function (index) {
								//check:if selected row has same DIR as of tokens. Trigger assign Unassign backedn call with DIR details
								if (that.oValueHelpDialog.getTable().getContextByIndex(selectedRows[index]).getObject().DocumentInfoRecord === that.aTokens[
										i].getText()) {
									that.addRemoveObjectLink(that.isAssign, that.oValueHelpDialog.getTable().getContextByIndex(selectedRows[index]).getObject(),
										that.aKeys);
									return false;
								}
							});
						}
					}
					that.oValueHelpDialog.destroy();
					that.oModel.attachBatchRequestCompleted(function (oEvent) {
						if (oEvent.getParameters().success) {
							that._retrieveAttachment(that, true);
						} else {
							that._showErrorMessage(that.getView().getModel("i18n").getResourceBundle().getText("DIR_Assignment_Failed"));
						}
					});
				},
				cancel: function (oControlEvent) {
					that.oValueHelpDialog.destroy();
				},
				tokenRemove: function (oEvent) {
					var removedTokens = oEvent.getParameters().tokenKeys[0];
					var selectedRows = that.oValueHelpDialog.getTable().getSelectedIndices();
					var rowsToRemove = [];
					jQuery.each(selectedRows, function (index) {
						if (that.oValueHelpDialog.getTable().getContextByIndex(selectedRows[index]).getObject().DocumentInfoRecord ===
							removedTokens) {
							rowsToRemove.push(selectedRows[index]);
						}
					});

					jQuery.each(rowsToRemove, function (index) {
						that.oValueHelpDialog.getTable().removeSelectionInterval(rowsToRemove[index], rowsToRemove[index]);
					});
					jQuery.each(that.aTokens, function (index) {
						if (that.aTokens[index].getKey() === removedTokens) {
							that.aTokens.splice(index, 1);
							return false;
						}
					});

				},
				selectionChange: function (oEvent) {
					var selectedIndex = oEvent.getParameters().tableSelectionParams.rowIndex;
					var selectedRows = that.oValueHelpDialog.getTable().getSelectedIndices();
					if (selectedIndex >= 0) {
						var selectedDIR = that.oValueHelpDialog.getTable().getContextByIndex(selectedIndex).getObject();
						// Logic: From current(nth) row gow n-x and N+y to check if same DIR exists, if yes mark selection true else it is remove selection
						var i = selectedIndex - 1;
						while (i >= 0) {
							var tempDIR = that.oValueHelpDialog.getTable().getContextByIndex(i).getObject();
							if (selectedRows.indexOf(selectedIndex) > -1) {
								if (selectedDIR.DocumentInfoRecord === tempDIR.DocumentInfoRecord) {
									that.oValueHelpDialog.getTable().addSelectionInterval(i, i);
									i--;
								} else {
									break;
								}
							} else {
								if (selectedDIR.DocumentInfoRecord === tempDIR.DocumentInfoRecord) {
									that.oValueHelpDialog.getTable().removeSelectionInterval(i, i);
									i--;
								} else {
									break;
								}
							}
						}
						i = selectedIndex + 1;
						while (i <= selectedIndex + 143 && i < that.oValueHelpDialog.getTable().getBinding().aKeys.length) {
							var tempDIR = that.oValueHelpDialog.getTable().getContextByIndex(i).getObject();
							if (selectedRows.indexOf(selectedIndex) > -1) {
								if (selectedDIR.DocumentInfoRecord === tempDIR.DocumentInfoRecord) {
									that.oValueHelpDialog.getTable().addSelectionInterval(i, i);
									i++;
								} else {
									break;
								}
							} else {
								if (selectedDIR.DocumentInfoRecord === tempDIR.DocumentInfoRecord) {
									that.oValueHelpDialog.getTable().removeSelectionInterval(i, i);
									i++;
								} else {
									break;
								}
							}
						}
						that.oValueHelpDialog.setTokens([]);
						//refresh tokens and if DIR is already there in token, don't add it, else add it
						jQuery.each(selectedRows, function (rowIndex) {
							var containsToken = false;
							if (rowIndex > that.oValueHelpDialog.getTable().getBinding().aKeys.length) {
								return false;
							}
							for (var j = 0; j < that.aTokens.length; j++) {
								if (that.aTokens[j].getText() === that.oValueHelpDialog.getTable().getContextByIndex(selectedRows[rowIndex]).getObject().DocumentInfoRecord) {
									containsToken = true;
									break;
								}
							}
							if (containsToken === false) {
								that.aTokens.push(new sap.m.Token({
									key: that.oValueHelpDialog.getTable().getContextByIndex(selectedRows[rowIndex]).getObject().DocumentInfoRecord,
									text: that.oValueHelpDialog.getTable().getContextByIndex(selectedRows[rowIndex]).getObject().DocumentInfoRecord
								}));
							}
						});
					}
					if (selectedRows.indexOf(selectedIndex) < 0) {
						var tempToken = [];
						jQuery.each(that.aTokens, function (index) {
							if (that.aTokens[index].getText() === (that.oValueHelpDialog.getTable().getContextByIndex(selectedIndex) ? that.oValueHelpDialog
								.getTable().getContextByIndex(selectedIndex).getObject().DocumentInfoRecord : "")) {
								tempToken.push(index);
								return false;
							}
						});
						jQuery.each(tempToken, function (index) {
							that.aTokens.splice(tempToken[index], 1);
						});
					}
					
					that.oValueHelpDialog.setTokens(that.aTokens);

				},
				updateSelection: function (oEvent) {
					// to make scroller to initial postion
					that.oValueHelpDialog.getTable().sort();
				}
			});
			
			that.oValueHelpDialog.setTokens([]);

			that.oValueHelpDialog.setModel(that.getView().getModel("i18n"), "i18n");
			var oColModel = new sap.ui.model.json.JSONModel();
			var arrObjCol = [];
			var arrObjCol1 = [];
			var objFilter = [];

			jQuery.each(i18nKeyData, function (key, value) {

				arrObjCol.push({
					label: "{i18n>" + value + "}",
					template: staticKeys[key]
				});

				arrObjCol1.push({
					label: "{i18n>" + value + "}",
					key: staticKeys[key]
				});
				objFilter.push(new sap.ui.comp.filterbar.FilterGroupItem({
					groupTitle: "advSearch",
					groupName: "advSearch",
					name: value,
					visible: (value === "ObjectKey" ? false : true),
					label: "{i18n>" + value + "}",
					control: that.getSearchFields(value)
				}));

			});

			oColModel.setData({
				cols: arrObjCol
			});
			that.oValueHelpDialog.setTable(new sap.ui.table.Table());
			that.oValueHelpDialog.getTable().setModel(oColModel, "columns");
			that.oValueHelpDialog.getTable().setModel(that.getOwnerComponent().getModel("i18n"), "i18n");
			if (that.oValueHelpDialog.getTable().bindItems) {
				var oTable = that.oValueHelpDialog.getTable();
				oTable.bindAggregation("items", "/", function (sId, oContext) {
					var aCols = oTable.getModel("columns").getData().cols;
					return new sap.m.ColumnListItem({
						cells: aCols.map(function (column) {
							var colname = column.template;
							return new sap.m.Label({
								text: "{" + colname + "}"
							});
						})
					});
				});
			}

			that.oValueHelpDialog.setRangeKeyFields(arrObjCol1);
			that.oValueHelpDialog.getTable().setEnableSelectAll(false);
			var blnSearchBox = false; //since both the search comes to filter bar to differentiate the basic search and filter bar
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: objFilter,
				search: function (oQuery) {
					var query = oQuery || "";
					var arg = arguments[0].getParameters(),
						searchedValue = "";
					var searchType = sap.ui.model.FilterOperator.Contains;
					var f = [], aFilter=[],
						filterBoxSearch;

					jQuery.each(i18nKeyData, function (key, value) {
						if (value !== "ObjectKey") {
							if (value !== "Type") {
								searchedValue = sap.ui.getCore().byId(query.getSource().getBasicSearch()).getValue() || "";
								if (searchedValue && searchedValue.length > 0) {
									f.push(new sap.ui.model.Filter(staticKeys[key], searchType, searchedValue));
								}
								filterBoxSearch = arg.selectionSet[key - 1].getValue();
								if (filterBoxSearch && filterBoxSearch.length > 0) {
									f.push(new sap.ui.model.Filter(staticKeys[key], searchType, filterBoxSearch));
								}
							} else {
								filterBoxSearch = arg.selectionSet[key - 1].getSelectedItem().getKey();
								if (filterBoxSearch !== "") {
									f.push(new sap.ui.model.Filter(staticKeys[key], searchType, filterBoxSearch));
								} else {
									searchedValue = sap.ui.getCore().byId(query.getSource().getBasicSearch()).getValue() || "";
									if (searchedValue && searchedValue.length > 0) {
										f.push(new sap.ui.model.Filter(staticKeys[key], searchType, searchedValue));
									}
								}
							}
						}
					});
					// aFilter = new sap.ui.model.Filter({
					// 	filters: f,
					// 	and: false
					// });
					that.oValueHelpDialog.setModel(that.oModel);
					if (isAssign) {
						that.oValueHelpDialog.getTable().bindRows({
							path: "/C_DocInfoRecdAttchDetForBusObj", // asign DIR
							filters: [
								new sap.ui.model.Filter({
									path: "LinkedSAPObject",
									operator: "EQ",
									value1: that._properties.objectType
								})
							].concat(f),
							sorters: [
								new sap.ui.model.Sorter({
									path: "DocumentInfoRecord"
								})
							],
							error: function (err) {
								self._showErrorMessage(JSON.parse(err.responseText).error.message.value, "");
							}
						});
					} else {
						that.oValueHelpDialog.getTable().bindRows({
							path: "/C_DocInfoRecdObjLinkAttchDet", // Unassign DIR
							filters: [
								new sap.ui.model.Filter({
									path: "LinkedSAPObject",
									operator: "EQ",
									value1: that._properties.objectType
								}),
								new sap.ui.model.Filter({
									path: "LinkedSAPObjectKey",
									operator: "EQ",
									value1: that._properties.objectKey
								})
							].concat(f),
							sorters: [
								new sap.ui.model.Sorter({
									path: "DocumentInfoRecord"
								})
							],
							error: function (err) {
								self._showErrorMessage(JSON.parse(err.responseText).error.message.value, "");
							}
						});
					}

					blnSearchBox = false; //resetting search vs filterbar
					that.oValueHelpDialog.update();
					that.oValueHelpDialog.getTable().attachFirstVisibleRowChanged(function(oEvent){
						var aRows = that.oValueHelpDialog.getTable().getRows();
						for(var i=0; i<that.aToken.length;i++){
							jQuery.each(aRows, function(row){
								if(row.getBindingContext().getObject().DocumentInfoRecord === that.aToken[i].DocumentInfoRecord)
								{
									that.oValueHelpDialog.getTable().addSelectionInterval(row.getIndex());
								}
							});
						}
					});
					that.oValueHelpDialog.getTable().getModel().attachBatchRequestCompleted(function (oEvent) {
						//if more records are fetched on scroll, if selected DIR is present in the fetched records, mark it as selected
						if (that.aTokens.length > 0) {
							if (that.oValueHelpDialog.getContent().length > 0) {
								var selectedRows = that.oValueHelpDialog.getTable().getSelectedIndices();
								var lastSelectedRow = selectedRows[selectedRows.length - 1];
								for (var i = lastSelectedRow + 1; i < that.oValueHelpDialog.getTable().getBinding().aKeys.length && i > 0; i++) {
									if (that.oValueHelpDialog.getTable().getContextByIndex(lastSelectedRow).getObject().DocumentInfoRecord === that.oValueHelpDialog
										.getTable().getContextByIndex(i).getObject().DocumentInfoRecord) {
										that.oValueHelpDialog.getTable().addSelectionInterval(i, i);
									} else {
										break;
									}
								}
							}
						}
					});
				}
			});
			that.oValueHelpDialog.setFilterBar(oFilterBar);
			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function (oEvent) {
						blnSearchBox = true;
						that.oValueHelpDialog.getFilterBar().search();
					}
				}));
			}
			that.oValueHelpDialog.setRangeKeyFields(arrObjCol1);
			that.oValueHelpDialog.open();
		}
	};
});
