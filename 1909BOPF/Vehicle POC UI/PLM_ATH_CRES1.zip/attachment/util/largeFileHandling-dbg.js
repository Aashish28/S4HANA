/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/base/Object",
	"sap/m/MessageBox"
], function (UI5Object, MessageBox) {
	"use strict";
	return {
		getFileFromUrl: function (FileId, docNumber, docType, docPart, docVersion, applicationId, downloadFromRep) {
			var featureToggleStatus = sap.s4h.cfnd.featuretoggle.lib.features().getFeatureStatus("IDEA_DMS_ATS_DOWNLOAD_LFH");
			var that = this;
			if (!that._objects) {
				that._objects.oModel = new sap.ui.model.odata.ODataModel(that._serviceUrl, true);
			}
			that._objects.oModel.callFunction("/GetAccessURLWithToken", {
				method: "GET",
				urlParameters: {
					"ObjectType": that._properties.objectType,
					"ObjectKey": that._properties.objectKey,
					"RequestURLForGet": true,
					"FileId": FileId,
					"DocumentInfoRecordDocNumber": docNumber ? docNumber : "",
					"DocumentInfoRecordDocType": docType ? docType : "",
					"DocumentInfoRecordDocPart": docPart ? docPart : "",
					"DocumentInfoRecordDocVersion": docVersion ? docVersion : "",
					"CountOfTokensRequired": 1
				},
				success: function (oData) {
					var _url = decodeURIComponent(oData.results[0].URLToReadAttachment);
					var _token = oData.results[0].SecureAccessToken;
					var sToken = {
						key: "X-AccessToken",
						value: _token
					};
					if (featureToggleStatus) {
						if (sToken && sToken.value) {
							if (parseInt(oData.results[0].FileSize, 10) <= 800000000) {
								var parameterUrl = that._serviceUrl + "/OriginalContentSet(Documenttype='" + (docType ? docType : "") +
									"',Documentnumber='" + (docNumber ? docNumber : "") + "',Documentpart='" + (docPart ? docPart : "") +
									"',Documentversion='" +
									(docVersion ? docVersion : "") + "',ApplicationId='" + (applicationId ? applicationId : "") + "',FileId='" + (FileId ?
										FileId : "") +
									"')/$value";
								sap.m.URLHelper.redirect(parameterUrl, true);
							} else {
								sap.m.MessageToast.show(that.getView().getModel("i18n").getResourceBundle().getText("MESSAGE_FILE_DOWNLOAD_TOAST"));
								var downloadStatus = that._downloadFilePromise(_url, oData.results[0].Filename, oData.results[0].ContentType, sToken);
								downloadStatus.then(function (resolveValue, response) {
									if (!resolveValue) {
										//that._downloadFilePromise(_url, oData.results[0].Filename, oData.results[0].ContentType, sToken);
										that._showErrorMessage(that.getView().getModel("i18n").getResourceBundle().getText("MESSAGE_DOWNLOAD_FAILED"), response);
									}
								});
							}
						} else {
							if (downloadFromRep) {
								that.downloadviaURL(_url, oData.results[0].Filename, oData.results[0].ContentType);
							} else {
								var parameterUrl = that._serviceUrl + "/OriginalContentSet(Documenttype='" + (docType ? docType : "") +
									"',Documentnumber='" + (docNumber ? docNumber : "") + "',Documentpart='" + (docPart ? docPart : "") +
									"',Documentversion='" +
									(docVersion ? docVersion : "") + "',ApplicationId='" + (applicationId ? applicationId : "") + "',FileId='" + (FileId ?
										FileId :
										"") +
									"')/$value";
								sap.m.URLHelper.redirect(parameterUrl, true);
							}
						}
					} else {
						if (downloadFromRep) {
							that.downloadviaURL(_url, oData.results[0].Filename, oData.results[0].ContentType);
						} else {
							var parameterUrl = that._serviceUrl + "/OriginalContentSet(Documenttype='" + (docType ? docType : "") +
								"',Documentnumber='" + (docNumber ? docNumber : "") + "',Documentpart='" + (docPart ? docPart : "") +
								"',Documentversion='" +
								(docVersion ? docVersion : "") + "',ApplicationId='" + (applicationId ? applicationId : "") + "',FileId='" + (FileId ? FileId :
									"") +
								"')/$value";
							sap.m.URLHelper.redirect(parameterUrl, true);
						}
					}
				},
				error: function (e) {
					return (that._showErrorMessage(JSON.parse(e.response.body).error.message.value, ""));
				}
			});
		},
		handleChange: function (oEvent) {

			// var files = oEvent.getParameters().files;
			// // this.getView().byId("fileUploader").destroyHeaderParameters();
			// try {
			// 	this.getUploadCollectionControl().setBusy(true);
			// 	jQuery.each(files, function(index) {
			// 		this.oModel.callFunction("/GetUploadURLWithToken", {
			// 			urlParameters: {
			// 				"ObjectType": this.getOwnerComponent().getObjectType(),
			// 				"ObjectKey": this.getOwnerComponent().getObjectKey(),
			// 				"Filename": files[index].name,
			// 				"MIMEType": files[index].type,
			// 				"CountOfTokensRequired": 2
			// 			},
			// 			changeSetId: "getUploadURL",
			// 			groupId: "getUploadURL",
			// 			error: function(error) {
			// 				this.getUploadCollectionControl().setBusy(false);
			// 				this._showErrorMessage(JSON.parse(error.responseText).error.message.value, "");
			// 				this._removeFileFromList(files[index].name);
			// 			}.bind(this),
			// 			success: function(oResponse, oData) {
			// 				// console.log(oResponse);
			// 				var uploadUrl = decodeURIComponent(oResponse.results[0].URLToUploadAttachment);
			// 				var formData = new FormData();
			// 				formData.append(files[index].name, files[index]);
			// 				var isAppend = uploadUrl.indexOf("append") !== -1;
			// 				// var blobObject = new Blob(files[index], {
			// 				// 	type: 'application/octet-stream'
			// 				// });
			// 				$.ajax({
			// 					context: this,
			// 					url: uploadUrl,
			// 					crossDomain: true,
			// 					beforeSend: function(request) {
			// 						request.setRequestHeader("X-AccessToken", oResponse.results[0].SecureAccessToken);
			// 					},
			// 					xhr: function() {
			// 						// Get new xhr object using default factory
			// 						var xhr = jQuery.ajaxSettings.xhr();
			// 						// Copy the browser's native setRequestHeader method
			// 						var setRequestHeader = xhr.setRequestHeader;
			// 						// Replace with a wrapper
			// 						xhr.setRequestHeader = function(name, value) {
			// 							// Ignore the X-Requested-With header
			// 							if (name === 'X-XHR-Logon' || name === 'X-Requested-With') {
			// 								return;
			// 							}
			// 							// Otherwise call the native setRequestHeader method
			// 							// Note: setRequestHeader requires its 'this' to be the xhr object,
			// 							// which is what 'this' is here when executed.
			// 							setRequestHeader.call(this, name, value);
			// 						};
			// 						// pass it on to jQuery
			// 						return xhr;
			// 					},
			// 					data: isAppend ? files[index] : formData,
			// 					type: isAppend ? 'PUT' : 'POST',
			// 					success: function() {
			// 						// debugger;
			// 						// this.finalizeMetadata({
			// 						// 	"ObjectType": "MARA",
			// 						// 	"ObjectKey": "TEST_MATERIAL",
			// 						// 	"Filename": files[index].name,
			// 						// 	"MIMEType": files[index].type,
			// 						// 	"ApplicationId": oResponse.results[0].ApplicationId,
			// 						// 	"FileId": oResponse.results[0].FileId
			// 						// });
			// 						this.oModel.callFunction("/FinalizeMetadata", {
			// 							method: "POST",
			// 							urlParameters: {
			// 								"ObjectType": this.getOwnerComponent().getObjectType(),
			// 								"ObjectKey": this.getOwnerComponent().getObjectKey(),
			// 								"Filename": files[index].name,
			// 								"MIMEType": files[index].type,
			// 								"ApplicationId": oResponse.results[0].ApplicationId,
			// 								"FileId": oResponse.results[0].FileId
			// 							},
			// 							changeSetId: "finalizeMetadata",
			// 							groupId: "finalizeMetadata",
			// 							success: function(oResponse) {
			// 								var oUploadCollection = this.getUploadCollectionControl();
			// 								oUploadCollection.setBusy(false);
			// 								var oData = oUploadCollection.getModel("__attachmentData").getData();
			// 								this.oResult.fileName = "";
			// 								this.uploadCountSuccess += 1;
			// 								oResponse.CreatedAt = new Date(oResponse.CreatedAt);
			// 								// this.getView().byId("attachmentServiceFileUpload").setBusy(true);
			// 								if (this.checkingIn || this.checkingInAsNewVersion) {
			// 									this._updateFile(oResponse);
			// 									this.checkingIn = false;
			// 									this.checkingInAsNewVersion = false;
			// 									this.fieldControlFileOperations("CheckIn");

			// 								} else {
			// 									this._removeFileFromList(oResponse.Filename);
			// 									// oUploadCollection.removeItems();
			// 									oData.dataitems.unshift(this._mapResult(oResponse));
			// 									this._setAttachmentModel(oData.dataitems);
			// 								}
			// 								this.oResult.status = "UPLOADSUCCESS";
			// 								this.getOwnerComponent().fireOnupload(this.oResult);
			// 							}.bind(this),
			// 							error: function() {
			// 								this.getUploadCollectionControl().setBusy(false);
			// 							}.bind(this)
			// 						});
			// 					},
			// 					contentType: false,
			// 					processData: false,
			// 					error: function(error) {
			// 						this.getUploadCollectionControl().setBusy(false);
			// 						jQuery.sap.log.error("Upload to repository failed");
			// 						this._removeFileFromList(files[index].name);
			// 						this._showErrorMessage(JSON.parse(error.responseText).error.message.value, "");
			// 					}.bind(this)
			// 				}).then(function() {

			// 				});
			// 				// this.getView().byId("fileUploader").addHeaderParameter(oheaderParameter);

			// 				// // this.getView().byId("fileUploader").addParameter(oheaderParameter);
			// 				// debugger;
			// 				// this.getView().byId("fileUploader").setUploadUrl(decodeURIComponent(oResponse.results[0].URLToUploadAttachment));

			// 			}.bind(this)
			// 		});
			// 	}.bind(this));

			// } catch (err) {
			// 	this.getUploadCollectionControl().setBusy(false);
			// 	jQuery.sap.log.error(err);
			// }
		},

		finalizeMetadata: function (oParameters, oContext) {

		},
		handleUploadPress: function () {
			this.getView().byId("fileUploader").upload();
		}
	};
});
