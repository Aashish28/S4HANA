//@ui5-bundle sap/se/mi/plm/lib/attachmentservice/library-h2-preload.js
/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.predefine('sap/se/mi/plm/lib/attachmentservice/library',['jquery.sap.global','sap/ui/core/library'],function(q){"use strict";sap.ui.getCore().initLibrary({name:"sap.se.mi.plm.lib.attachmentservice",version:"7.0.11",dependencies:["sap.ui.core","sap.m","sap.s4h.cfnd.featuretoggle"],types:[],interfaces:[],controls:["sap.se.mi.plm.lib.attachmentservice.controls.Example"],elements:[]});return sap.se.mi.plm.lib.attachmentservice;},false);
sap.ui.require.preload({
	"sap/se/mi/plm/lib/attachmentservice/manifest.json":'{"_version":"1.1.0","sap.app":{"_version":"1.1.0","id":"sap.se.mi.plm.lib.attachmentservice","type":"library","embeds":["attachment","attachment/components/stcomponent","attachment/components/fscomponent"],"i18n":"attachment/i18n/i18n.properties","applicationVersion":{"version":"7.0.11"},"title":"{{title}}","description":"{{description}}","ach":"PLM-FIO-DMS","dataSources":{"CV_ATTACHMENT_SRV_Entities":{"uri":"/sap/opu/odata/sap/CV_ATTACHMENT_SRV/"}},"resources":"resources.json","offline":false},"sap.ui":{"_version":"1.1.0","technology":"UI5","deviceTypes":{"desktop":true,"tablet":true,"phone":true},"supportedThemes":["sap_hcb","sap_bluecrystal"]},"sap.ui5":{"_version":"1.1.0","dependencies":{"minUI5Version":"1.30.0","libs":{"sap.ui.core":{"minUI5Version":"1.30.0"},"sap.s4h.cfnd.featuretoggle":{"lazy":true}}},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"sap.se.mi.plm.lib.attachmentservice.attachment.i18n.i18n"}}},"contentDensities":{"compact":true,"cozy":false}},"sap.platform.abap":{"_version":"1.1.0","uri":"/sap/bc/bsp/sap/plm_ath_cres1/"},"sap.platform.hcp":{"_version":"1.1.0","uri":""},"sap.fiori":{"_version":"1.1.0","registrationIds":["F1243"],"archeType":"reusecomponent"}}'
},"sap/se/mi/plm/lib/attachmentservice/library-h2-preload"
);
sap.ui.loader.config({depCacheUI5:{
"sap/se/mi/plm/lib/attachmentservice/attachment/Component.js":["sap/ui/core/UIComponent.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/components/fscomponent/Component.js":["sap/se/mi/plm/lib/attachmentservice/attachment/Component.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/components/stcomponent/Component.js":["sap/suite/ui/generic/template/extensionAPI/ReuseComponentSupport.js","sap/ui/core/UIComponent.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/fragment/checkInActionSheet.fragment.xml":["sap/m/ActionSheet.js","sap/m/Button.js","sap/ui/core/Fragment.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/fragment/grouping.fragment.xml":["sap/m/ViewSettingsDialog.js","sap/m/ViewSettingsFilterItem.js","sap/m/ViewSettingsItem.js","sap/ui/core/Fragment.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/localService/mockserver.js":["sap/ui/core/util/MockServer.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/util/assignUnassignDIR.js":["sap/m/MessageBox.js","sap/ui/base/Object.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/util/largeFileHandling.js":["sap/m/MessageBox.js","sap/ui/base/Object.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/view/Attachment.controller.js":["sap/m/GroupHeaderListItem.js","sap/m/MessageBox.js","sap/se/mi/plm/lib/attachmentservice/attachment/util/assignUnassignDIR.js","sap/se/mi/plm/lib/attachmentservice/attachment/util/largeFileHandling.js","sap/ui/core/format/DateFormat.js","sap/ui/core/format/FileSizeFormat.js","sap/ui/core/mvc/Controller.js","sap/ui/model/Filter.js","sap/ui/model/FilterOperator.js","sap/ui/model/Sorter.js"],
"sap/se/mi/plm/lib/attachmentservice/attachment/view/Attachment.view.xml":["sap/m/Button.js","sap/m/Label.js","sap/m/Link.js","sap/m/ObjectAttribute.js","sap/m/ObjectStatus.js","sap/m/OverflowToolbar.js","sap/m/Select.js","sap/m/Title.js","sap/m/Toolbar.js","sap/m/ToolbarSpacer.js","sap/m/UploadCollection.js","sap/m/UploadCollectionItem.js","sap/m/UploadCollectionToolbarPlaceholder.js","sap/m/VBox.js","sap/se/mi/plm/lib/attachmentservice/attachment/view/Attachment.controller.js","sap/ui/core/CustomData.js","sap/ui/core/Icon.js","sap/ui/core/ListItem.js","sap/ui/core/mvc/XMLView.js"],
"sap/se/mi/plm/lib/attachmentservice/library.js":["jquery.sap.global.js","sap/ui/core/library.js"]
}});
//# sourceMappingURL=library-h2-preload.js.map
