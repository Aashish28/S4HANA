sap.ui.controller("com.vehicle.ext.controller.ListReportExt", {

	onInit: function () {
		// Disable navigation
		/*	this.byId("listReport").getTable().attachUpdateFinished(function (oEvent) {
				for (var j = 0; j < oEvent.getSource().getItems().length; j++) {
				oEvent.getSource().getItems()[j].setType(sap.m.ListType.Inactive);
				}
			});*/
	},

	onBeforeRebindTableExtension: function (oEvent) {
		var oBindingParams = oEvent.getParameter("bindingParams");
		oBindingParams.parameters = oBindingParams.parameters || {};

		var oSmartTable = oEvent.getSource();
		var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
		var vStatus;
		if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {
			//Custom price filter
			var oCustomControl = oSmartFilterBar.getControlByKey("StatusFilter");
			if (oCustomControl instanceof sap.m.ComboBox) {
				vStatus = oCustomControl.getSelectedKey();
				if (vStatus) {
					oBindingParams.filters.push(new sap.ui.model.Filter("VehicleStatus", "EQ", vStatus));
				}
			}
		}
	},
	/*
	 * Content of the custom field shall be stored in the app state, so that it can be restored later again e.g. after a back navigation.
	 * @param oCustomData  : referance to the custome data.
	 */
	getCustomAppStateDataExtension: function (oCustomAppData) {
		/*
		var oCustomField1 = this.oView.byId("SampleFilterFieldID");
		if (oCustomField1) {
			oCustomAppData.SampleFilterFieldID = oCustomField1.getValue();
		}
		return oCustomAppData;
		*/
	},
	/*
	 * In order to restore content of the custom field in the filterbar e.g. after a back navigation.
	 * @param oCustomData  : referance to the custome data.
	 */
	restoreCustomAppStateDataExtension: function (oCustomAppData) {
		/*
		if (oCustomAppData.SampleFilterFieldID !== undefined) {
			if ( this.oView.byId("SampleFilterFieldID") ) {
				this.oView.byId("SampleFilterFieldID").setSelectedKey(oCustomAppData.SampleFilterFieldID);
			}
		}
		*/
	},
	onClickActionYZA_C_VEH1: function (oEvent) {
		/*var oCrossAppNav = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
			var href_For_Product_display = (oCrossAppNav && oCrossAppNav.toExternal({
				target: {
					shellHash: "YZA_C_VEHTYPE-display"
				}
			})) || "";*/
			
			if(sap.ushell && sap.ushell.Container && sap.ushell.Container.getService){
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
	            oCrossAppNavigator.toExternal({
	                target : { semanticObject : "VehicleType", action : "display" },
	                params : {
	                		  "VehicleTypeText"  : "*test*"
	                         /* "material" : oEvent.getSource().getInfo(),
	                          "description": oEvent.getSource().getDescription()*/
	                }
	            });
	        }else{
	            alert("App to app navigation is not supported in this mode");
	        }
	}
	
	// Overwrite standard function
/*	onListNavigationExtension: function(){
		var oNavigationController = this.extensionAPI.getNavigationController();
		//var oBindingContext = oEvent.getSource().getBindingContext();
		//var oObject = oBindingContext.getObject();
		oNavigationController.navigateExternal("ExampleNavigationTarget", {
			//"anyParamName": oObject.id// Note this is the proprty name from odata
		});
		return true;
	},*/
	
/*	 onListNavigationExtension: function(oEvent) {
         var oNavigationController = this.extensionAPI.getNavigationController();
         var oBindingContext = oEvent.getSource().getBindingContext();
         var oObject = oBindingContext.getObject();
         if (oObject.FuleType == "P") {
            oNavigationController.navigateInternal("", {     
                routeName: "toCanvasPage"
            });  
         } else {
            // return false to trigger the default internal navigation
            return false;
         }
         // return true is necessary to prevent further default navigation
         return true;
     }*/

	
	/*onPress: function(oEvent) {
		 
			// get a handle on the global XAppNav service
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); 
			oCrossAppNavigator.isIntentSupported(["employeeId-display"])
				.done(function(aResponses) {

				})
				.fail(function() {
					new sap.m.MessageToast("Provide corresponding intent to navigate");
				});
			// generate the Hash to display a employee Id
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "employeeId",
					action: "display"
				}
			})) || ""; 
			//Generate a  URL for the second application
			var url = window.location.href.split('#')[0] + hash; 
			//Navigate to second app
			sap.m.URLHelper.redirect(url, true); 
		}*/
});