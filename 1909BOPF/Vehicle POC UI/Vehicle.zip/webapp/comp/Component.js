sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/suite/ui/generic/template/extensionAPI/ReuseComponentSupport",
	"sap/ui/Device",
], function (UIComponent,ReuseComponentSupport, Device) {
	"use strict";

	return UIComponent.extend("com.vehicle.comp.Component", {

		metadata: {
			manifest: "json",
			properties: {
                /* Standard properties for reuse components */
                mode: {
                    type: "string",
                    group: "standard"
                },
                semsnticObject: {
                    type: "string",
                    group: "standard"
                },
                stIsAreaVisible: {
                    type: "boolean",
                    group: "standard"
                },

                /* Component specific properties */
                documentNumber: {
                    type: "string",
                    group: "specific",
                    bindable: true,
                    defaultValue: ""
                }
			}
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
		/*	//Transform this component into a reuse component for Fiori Elements:
            ReuseComponentSupport.mixInto(this, "compModel");
            
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);*/
			
			 // Defensive call of init of the super class:
			   (UIComponent.prototype.init || jQuery.noop).apply(this, arguments);
			    //Transform this component into a reuse component for Fiori Elements:
			    ReuseComponentSupport.mixInto(this, "myPropertiesModelName");
			    // Technique 2: Attach to changes of the component model
			    /*var oMyPropertiesModel = this.getComponentModel();
			    var oPropertyBinding = oMyPropertiesModel.bindProperty("/documentNumber");
			    oPropertyBinding.attachChange(function(){
			      var sDocumentNumber = oMyPropertiesModel.getProperty("/documentNumber");
			      debugger;
			      // ... (any code that wants to consume the changed document number)
			    });*/

			// enable routing
			this.getRouter().initialize();

			// set the device model
			//this.setModel(models.createDeviceModel(), "device");
		}
		
/*		setProperty: function (sName, oValue) {
			sap.ui.core.UIComponent.prototype.setProperty.apply(this, arguments);
		},
			
		setDocumentNumber: function (value) {
				this.setProperty("documentNumber", value);
				this.page.getController().setDocumentNumberProperty(value);
		}*/
	});
});