sap.ui.define([
	"com/parent/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.parent.controller.App", {
		onInit: function () {
			// apply content density mode to root view
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
		}
	});
});