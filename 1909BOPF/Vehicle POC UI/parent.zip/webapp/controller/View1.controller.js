sap.ui.define([
	"com/parent/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.parent.controller.View1", {

		onInit: function () {
			var oMainModel = this.getOwnerModel("mainModel");
			this.initializeMessageManager(oMainModel);
			this.getRouter().getRoute("RouteView1").attachMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function () {

		},
		
		onComponentCreated:function(oEvent){
			debugger;
			var oComp = oEvent.getParameter("component");
				oComp.attachCompButtonPress(this.onCompButtonPress);
		},
		
		onCompButtonPress: function(oEvent){
			
		}

		//######## Public methods ########

		//######## Private methods ########

		//######## Public Event Handlers ########

		//######## Private Event Handlers ########

	});
});