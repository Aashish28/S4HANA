sap.ui.define(["sap/ui/generic/app/AppComponent"], function (AppComponent) {
	return AppComponent.extend("com.VehicleAlp.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});