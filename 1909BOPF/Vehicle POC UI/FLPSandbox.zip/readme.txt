This project contains all intents required for app to app navigation.

To enable navigation between apps, the neo-app.json and the fioriSandoxConfig.json files are updated in this project, as well as the .project.json file of the origin and the target apps.

To implement the navigation, you need to change the origin app as described in step 5.9 of the App to App Navigation blog (https://blogs.sap.com/2018/03/05/fiori-app-to-app-navigation-in-web-ide-full-stack/).

When implementing the navigation code, make sure you use the same intent as the one defined in the fioriSandoxConfig.json file.

Run the "SAP Fiori Launchpad Sandbox" configuration of the FLPsandbox project with the "Use my workspace first" checkbox selected when testing the navigation.

The following APIs contain information that can help you establish the navigation between apps:

CrossApplicationNavigation - https://sapui5.hana.ondemand.com/#/api/sap.ushell.services.CrossApplicationNavigation/overview 

NavigationHandler - https://sapui5.hana.ondemand.com/#/api/sap.ui.generic.app.navigation.service.NavigationHandler