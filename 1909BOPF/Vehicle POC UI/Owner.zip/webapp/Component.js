sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function (AppComponent) {
	return AppComponent.extend("com.owner.Component", {
		metadata: {
			"manifest": "json"
		}
	});
});