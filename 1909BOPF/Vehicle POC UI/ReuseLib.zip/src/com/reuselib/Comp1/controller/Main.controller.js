sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.reuselib.Comp1.controller.Main", {
		onInit: function () {

		},
		onPress:function(oEvent){
			this.getOwnerComponent().fireCompButtonPress({
            	button : oEvent
	        });
		}
	});
});