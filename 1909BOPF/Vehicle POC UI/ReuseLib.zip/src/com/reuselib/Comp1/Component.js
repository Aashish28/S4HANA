sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/suite/ui/generic/template/extensionAPI/ReuseComponentSupport",
	"sap/ui/Device"
], function (UIComponent, ReuseComponentSupport, Device) {
	"use strict";

	return UIComponent.extend("com.reuselib.Comp1.Component", {

		metadata: {
			manifest: "json",
			properties: {
				/* Standard properties for reuse components */
				mode: {
					type: "string",
					group: "standard"
				},
				appType: {
					type: "string",
					group: "standard"
				},
				stIsAreaVisible: {
					type: "boolean",
					group: "standard"
				},

				/* Component specific properties */
				documentNumber: {
					type: "string",
					group: "specific",
					defaultValue: ""
				}
			},
			events: {
				compButtonPress: {
					parameters: {
						button: {
							type: "object"
						}
					}
				}
			}
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			//Transform this component into a reuse component for Fiori Elements:
			ReuseComponentSupport.mixInto(this, "compModel");

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing need rounting or not
			//Since main view is default view no need routing optional
			 //this.getRouter().initialize();

			// set the device model
			//this.setModel(models.createDeviceModel(), "device");
		},
		
		/*  Manual conten creation optional*/
		/*	createContent: function() {
				this.page = new sap.ui.view({
					viewName: "com.reuselib.Comp1.view.Main",
					type: sap.ui.core.mvc.ViewType.XML
				});
				return this.page;
		}*/
		
	});
});