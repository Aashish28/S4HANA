/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library com.reuselib.
 */
sap.ui.define(["sap/ui/core/library"], // library dependency
	function () {

		"use strict";

		/**
		 * Reusable Library
		 *
		 * @namespace
		 * @name com.reuselib
		 * @author SAP SE
		 * @version 1.0.0
		 * @public
		 */

		// delegate further initialization of this library to the Core
		sap.ui.getCore().initLibrary({
			name: "com.reuselib",
			version: "1.0.0",
			dependencies: ["sap.ui.core"],
			types: [],
			interfaces: [],
			controls: [],
			elements: []
		});

		/* eslint-disable */
		return com.reuselib;
		/* eslint-enable */

	}, /* bExport= */ false);