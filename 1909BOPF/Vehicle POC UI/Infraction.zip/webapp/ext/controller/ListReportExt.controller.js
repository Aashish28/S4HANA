sap.ui.define([
	"sap/suite/ui/generic/template/extensionAPI/extensionAPI"
], function (extensionAPI) {
	"use strict";

	return sap.ui.controller("saaq.infraction.ext.controller.ListReportExt", {

		_mViewSettingsDialogs: {},

		onClickActionxSAAQxZ_C_INFRACTION1: function (oEvent) {

			var oViewModel = this.getView().getModel("viewModel"),
				oDialog = this.createDialog("saaq.infraction.ext.fragments.updateFields");
			oViewModel.setData({
				"Field": "",
				"Value": "",
				"DataType":""
			});
			oDialog.open();
		},
		
		onFieldSelect:function(oEvent){
			var oSf = this.byId("sfUpdFields"),
				oSelectedItem = oEvent.getSource().getSelectedItem().getBindingContext().getObject();	
				this.getView().getModel("viewModel").setProperty("/DataType",oSelectedItem.DataType);
				oSf.addContent(this._getField(oSf,oSelectedItem));
		},
		
		_getField: function(oSf,oSelectedItem){
			jQuery.sap.require("sap.m.Input");
			var oValue, sType;
			if(oSelectedItem.DataType.indexOf("INT") > -1){
				sType = "Number";
			}else{
				sType = "Text";
			}
			oSf.removeContent(3);
			oValue = new sap.m.Input({"type" : sType}).bindProperty("value", "viewModel>/Value");
			return oValue;
		},

		createDialog: function (sDialogFragmentName) {
			var oView = this.getView(),
				oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(oView.getId(), sDialogFragmentName, this);
				// connect dialog to view (models, lifecycle)
				//oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
				oView.addDependent(oDialog);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;
			}
			return oDialog;
		},

		onSaveDialog: function (oEvent) {
			var oModel = this.getView().getModel(),
				oViewModel = this.getView().getModel("viewModel"),
				oViewData = oViewModel.getData(),
				oTable = this.byId("listReport").getTable(),
				aContext = oTable.getSelectedContexts(),
				sDefaultGrpId = "updateInfractionGrp";
			oModel.setDeferredGroups([sDefaultGrpId]);

			var mParameters = {
					"groupId": sDefaultGrpId
				},
				oSelectedRow = {},
				//oSelectedItem = {},
				sSelectedPath = "",
				oItem = {};
			for (var i = 0; i < aContext.length; i++) {
				oSelectedRow = aContext[i];
				//oSelectedItem = oSelectedRow.getObject();
				sSelectedPath = oSelectedRow.sPath;
				oItem[oViewData.Field] = this._getValue(oViewData);
				oModel.update(sSelectedPath, oItem, mParameters);
			}
			this.getView().setBusy(true);
			oModel.submitChanges({
				groupId: sDefaultGrpId,
				success: this._onInfractionUpdateSuccess.bind(this),
				error: this._onInfractionUpdateFail.bind(this)
			});
			oModel.setRefreshAfterChange(true);
			this._mViewSettingsDialogs["saaq.infraction.ext.fragments.updateFields"].close();
		},

		onCloseDialog: function (oEvent) {
			this.byId("listReport").getTable().removeSelections();
			this._mViewSettingsDialogs["saaq.infraction.ext.fragments.updateFields"].close();
		},

		_onInfractionUpdateSuccess: function () {
			this.byId("listReport").getTable().removeSelections();
			this.getView().setBusy(false);
		},

		_onInfractionUpdateFail: function () {
			this.getView().setBusy(false);
		},
		
		_getValue: function(oViewData){
			var sValue;
			if(oViewData.DataType.indexOf("INT") > -1){
				sValue = parseInt(oViewData.Value,10);
			}else{
				sValue = oViewData.Value;
			}
			return sValue;
		}

	});
});